/**
 * @license Copyright (c) 2003-2017, CKSource - Frederico Knabben. All rights reserved.
 * For licensing, see LICENSE.md or http://ckeditor.com/license
 */
CKEDITOR.plugins.setLang( 'widget', 'nb', {
	'move': 'Klikk og dra for å flytte',
	'label': 'Widget %1'
} );
